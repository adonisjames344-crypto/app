# IKAJINET CYBER CAFÉ Android Project

Offline-first Android starter project.

## Build
Open this folder in Android Studio, let Gradle sync, then choose:
Build → Build App Bundle(s) / APK(s) → Build APK(s).

Package: `com.ikajinet.cybercafe`
Version: 1.0

This first Android build includes Dashboard, Sales, Services/Price List, Expenses, Stock placeholder and Reports. Data for sales/expenses is stored locally using SharedPreferences.
