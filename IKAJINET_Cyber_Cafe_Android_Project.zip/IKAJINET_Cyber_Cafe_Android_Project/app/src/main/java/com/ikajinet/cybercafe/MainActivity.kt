package com.ikajinet.cybercafe

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.text.NumberFormat
import java.util.*

class MainActivity : Activity() {
    private val green = Color.rgb(8,127,91)
    private val prefs by lazy { getSharedPreferences("ikajinet", MODE_PRIVATE) }
    private var sales = 0.0
    private var expenses = 0.0
    private var transactions = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sales = prefs.getFloat("sales",0f).toDouble()
        expenses = prefs.getFloat("expenses",0f).toDouble()
        transactions = prefs.getInt("transactions",0)
        showDashboard()
    }

    private fun money(v: Double) = "KSh " + NumberFormat.getNumberInstance(Locale.US).format(v)

    private fun showDashboard() {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL
        val head=TextView(this); head.text="IKAJINET CYBER CAFÉ\nCyber Café Management System"; head.setTextColor(Color.WHITE); head.textSize=20f; head.setPadding(20,24,20,24); head.setBackgroundColor(green)
        root.addView(head)
        val nav=LinearLayout(this); nav.gravity=Gravity.CENTER; nav.setPadding(6,6,6,6)
        listOf("Dashboard","Sales","Services","Expenses","Stock","Reports").forEach { n ->
            val b=Button(this); b.text=n; b.setOnClickListener { when(n){"Dashboard"->showDashboard();"Sales"->showSales();"Services"->showServices();"Expenses"->showExpenses();"Stock"->showStock();"Reports"->showReports()} }; nav.addView(b,LinearLayout.LayoutParams(0,55,1f))
        }
        root.addView(nav)
        val body=LinearLayout(this); body.orientation=LinearLayout.VERTICAL; body.setPadding(18,15,18,15)
        addCard(body,"Today's Sales",money(sales)); addCard(body,"Transactions",transactions.toString()); addCard(body,"Expenses",money(expenses)); addCard(body,"Estimated Profit",money(sales-expenses))
        val quick=Button(this); quick.text="RECORD QUICK SALE"; quick.setOnClickListener{showSales()}; body.addView(quick)
        root.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun addCard(p:LinearLayout,title:String,value:String){ val t=TextView(this); t.text="$title\n$value"; t.textSize=18f; t.setPadding(18,18,18,18); p.addView(t) }

    private fun showSales(){
        val l=screen("Sales & Payments"); val service=EditText(this); service.hint="Service (e.g. Printing)"
        val amount=EditText(this); amount.hint="Amount (KSh)"; amount.inputType=2
        val b=Button(this); b.text="RECORD SALE"; b.setOnClickListener{val a=amount.text.toString().toDoubleOrNull(); if(a==null){toast("Enter amount")}else{sales+=a;transactions++;save();toast("Sale recorded");showDashboard()}}
        l.addView(service);l.addView(amount);l.addView(b);l.addView(TextView(this).apply{text="Total sales: ${money(sales)}\nTransactions: $transactions";textSize=18f});setContentView(l)
    }
    private fun showServices(){val l=screen("Services & Price List"); listOf("Photocopy — KSh 10","Printing — KSh 10","Passport Photo (4) — KSh 150","KRA PIN Application — KSh 100","eCitizen Services — KSh 100","HELB Services — KSh 100","SHA Application — KSh 100","KUCCPS Application — KSh 100").forEach{x->l.addView(TextView(this).apply{text=x;textSize=17f;setPadding(10,16,10,16)})};setContentView(l)}
    private fun showExpenses(){val l=screen("Expenses");val desc=EditText(this);desc.hint="Expense description";val amt=EditText(this);amt.hint="Amount (KSh)";amt.inputType=2;val b=Button(this);b.text="RECORD EXPENSE";b.setOnClickListener{val a=amt.text.toString().toDoubleOrNull();if(a==null)toast("Enter amount")else{expenses+=a;save();toast("Expense recorded");showDashboard()}};l.addView(desc);l.addView(amt);l.addView(b);setContentView(l)}
    private fun showStock(){val l=screen("Stock");l.addView(TextView(this).apply{text="Stock management module ready. Add stationery, paper, ink and other supplies in the next release.";textSize=18f});setContentView(l)}
    private fun showReports(){val l=screen("Reports");l.addView(TextView(this).apply{text="SALES: ${money(sales)}\nEXPENSES: ${money(expenses)}\nNET: ${money(sales-expenses)}\nTRANSACTIONS: $transactions";textSize=20f});setContentView(l)}
    private fun screen(title:String):LinearLayout{val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(18,20,18,20);l.addView(TextView(this).apply{text=title;textSize=26f;setTextColor(green);setPadding(0,0,0,20)});return l}
    private fun save(){prefs.edit().putFloat("sales",sales.toFloat()).putFloat("expenses",expenses.toFloat()).putInt("transactions",transactions).apply()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
